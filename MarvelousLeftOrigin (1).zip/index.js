const { Discord, Client, Intents, MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu, SelectMenuInteraction, SelectMenuOptionBuilder, Modal, TextInputComponent, ButtonStyle, DiscordModal, ModalBuilder, ModalField } = require('discord.js');
const { Permissions } = require('discord.js');
const db = require('pro.db');
const { EventEmitter } = require('events');
EventEmitter.defaultMaxListeners = 15;
const fs = require('fs');

const client = new Client({
    intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
        Intents.FLAGS.DIRECT_MESSAGES,
    ],
    presence: {
        activities: [
            {
                name: 'Vip S 3mk',
                type: 'STREAMING',
                url: 'https://www.twitch.tv/yourstream',
            },
        ],
    },
});
client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});
const allowedChannels = ['1201495550453878918','1201495553385709588','1201495555579334676','1201495560289538048','1201495562395062363'];

client.on('messageCreate', async (message) => {
    try {
        if (message.author.bot) return;
        if (allowedChannels.includes(message.channel.id)) {
            await message.delete();
            const attachment = message.attachments.first();
            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('request_order')
                        .setLabel('Order Now!')
                        .setEmoji('<:p_credit_card:1081087599327846491>')
                        .setStyle('SECONDARY'),
                    new MessageButton()
                        .setCustomId('seller_button')
                        .setLabel('Author')
                        .setEmoji('<:p_at_sign:1081191097549733938>')
                        .setStyle('SECONDARY'),
                    new MessageButton()
                        .setCustomId('delete_button')
                        .setLabel('Remove')
                        .setEmoji('<:p_trash:1081102026026528838>')
                        .setStyle('SECONDARY')
                );
            const sentMessage = await message.channel.send({
                content: `**${message.content}**\n\n|| @here ||`,
                components: [row],
                files: attachment ? [attachment.url] : [],
            });

const tickets = await db.get("tickets") || {}
            tickets[sentMessage.id] = {
                owner: message.author.id,
                seller: message.author.id,
                offer: message.content,
            };
      db.set('tickets',tickets)
        }
    } catch (error) {
        console.error('Error processing message:', error);
    }
});



client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

   const tickets = await db.get(`tickets`) || {}
  let ticket = tickets[interaction.message.id];

   if (interaction.customId.includes('&')) {
     const msgID = interaction.customId.split('&')[1];
     ticket = tickets[msgID];
   }

    if (!ticket) return interaction.reply({content: "لم يتم العثور علي هذه التذكره", ephemeral:true})

    switch (interaction.customId.split('&')[0]) {
        case 'request_order'://هو ده 

  try {

    const row12 = new MessageActionRow()

        .addComponents(

          new MessageButton()

            .setCustomId('order_now'+'&'+interaction.message.id)

            .setLabel('Open Ticket')

            .setEmoji('<:p_credit_card:1081087599327846491>')

            .setStyle('PRIMARY'),

          new MessageButton()

            .setCustomId('Cancel')

            .setLabel('Cancel')



            .setStyle('SECONDARY'),

        );

                          await interaction.reply({ content: `**هل انت متأكد من فتح تذكرة شراء على هذا المنتج؟ |**`, components: [row12], ephemeral: true });

    } catch (error) {

      console.error('Error processing button click:', error);
  }
        break;

        case 'order_now':
            try {
                const ownerMention = `<@${ticket.owner}>`;
                await interaction.user.send(`لقد تم إضافة البوت للتذكرة. الرجاء الانتظار حتى يتم الرد. ${ownerMention}`);

                const categoryID = '1207377569763168408';
                const channel = await interaction.guild.channels.create(`order-${interaction.user.username}`, {
                    type: 'text',
                    parent: categoryID,
                  permissionOverwrites: [
                      {
                          id: interaction.user.id,
                          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
                      },
                      {
                          id: ticket.owner,
                          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
                      },
                      {
                          id: interaction.guild.roles.everyone.id,
                          deny: ['VIEW_CHANNEL'],
                      },
                  ],
                });
                const sellerMention = `<@${ticket.seller}>`;
                await interaction.reply({ content: `تم إنشاء تذكرتك في ${channel}`, ephemeral: true });
                const embed = new MessageEmbed()
                    .setTitle('طلب عرض')
                    .setDescription(`**
\`\`\`Order Informations\`\`\` ___${ticket.offer}___

**\n\n**

\`\`\`Terms of Service\`\`\` 
- انت الان ${interaction.user} فتحت الطلبات 
- يرجى انتظار البائع ${sellerMention} وعدم المنشنه 
- اذا البائع فخمول الرجاء ندائه عن طريق الأزرار اسفل 
- عند فتحك للتكت يتم نداء البائع تلقائي**`);
                const row = new MessageActionRow()
                    .addComponents(
                        new MessageButton()
                            .setCustomId('lock_button'+'&'+interaction.customId.split('&')[1])
                            .setLabel('قفل التذكرة')
                            .setEmoji('<:p_trash:1081102026026528838>')
                            .setStyle('SECONDARY'),
                        new MessageButton()
                            .setCustomId('call_button'+'&'+interaction.customId.split('&')[1])
                            .setLabel('نداء بائع')
                            .setEmoji('<:p_users:1081112026375524402>')
                            .setStyle('SECONDARY'),
                    );
                await channel.send({ embeds: [embed], components: [row] });
            } catch (error) {
                console.error('Error processing button click:', error);
            }
            break;

        case 'seller_button':
            try {
                const sellerRoleID = '1201495335680356374';
                const seller = interaction.guild.roles.cache.get(sellerRoleID);
                if (interaction.member.roles.cache.has(sellerRoleID)) {
                    const hiddenOfferMention = `<@${ticket.owner}>`;
                    await interaction.reply({ content: `**صاحب العرض: ${hiddenOfferMention}**🙂`, ephemeral: true });
                } else {
                    await interaction.reply({ content: '**لا يمكنك استخدام هذا امر مخصص للأدارة🙄**', ephemeral: true });
                }
            } catch (error) {
                console.error('Error processing button click:', error);
            }
            break;

        case 'delete_button':
            try {
                if (interaction.user.id === ticket.owner) {
                    await interaction.message.delete();
                    await interaction.reply({ content: '**تم حذف العرض بنجاح✅**', ephemeral: true });
                } else {
                    await interaction.reply({ content: '**لا يمكنك حذف عرض لأنك لست صاحبه 🙄**', ephemeral: true });
                }
            } catch (error) {
                console.error('Error processing button click:', error);
            }
            break;

        case 'lock_button':
            try {
                await interaction.reply({ content: '**سيتم حذف التذكرة بعد 5 ثواني 🙄**', ephemeral: true });
                setTimeout(async () => {
                    await interaction.message.channel.delete();
                }, 5000);
            } catch (error) {
                console.error('Error processing button click:', error);
            }
            break;

      case 'call_button':
      try {
          const owner = client.users.cache.get(ticket.owner); // الحصول على المستخدم صاحب العرض
          if (owner) {
              await owner.send("تم استدعائك من قبل البائع للرد على العرض."); // إرسال رسالة خاصة لصاحب العرض
              await interaction.reply({ content: '**تم استدعاء البائع بنجاح✅**', ephemeral: true }); // إرسال رد في القناة
          } else {
              throw new Error('Unable to find the owner of the ticket.'); // رسالة خطأ إذا لم يتم العثور على المالك
          }
      } catch (error) {
          console.error('Error processing button click:', error);
      }
      break;
    }
});

client.login(process.env.token);
